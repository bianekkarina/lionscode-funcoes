/*
Crie uma função chamada minutesToSeconds que aceite um número de minutos como parâmetro
e retorne o equivalente em segundos.

Programa desenvolvido por:
  - Alexandre
 - José
 - Kailane
 - Karina
*/

function minutesToSeconds(minutes) {
    return minutes * 60
}

//exemplos de uso
console.log(minutesToSeconds(2))
console.log(minutesToSeconds(4))
